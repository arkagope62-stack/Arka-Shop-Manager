# Arka Shop Manager — Android starter project

Shop: Gandeswari Jharai maslar dokan  
Platform: Android  
Languages planned: Hindi + English (Bengali can be added)

## Included in this first development build
- Native Android project using Kotlin and Jetpack Compose
- Room local database (records persist on the device)
- Shop dashboard with recorded sales, expenses, product count and low-stock count
- Product creation with purchase price, selling price, opening stock and unit
- Basic sale-total entry with payment mode and sales history
- Customer contact list
- Expense entry and history

## Open the project
1. Install Android Studio on a computer.
2. Choose **Open** and select this `ArkaShopManager` folder.
3. Allow Gradle sync and install the required Android SDK (API 35).
4. Run the `app` configuration on an Android phone or emulator.

## Important limitations — not yet production-ready
This is a functional starter, not the complete 90+ feature specification and not a signed APK.
The current quick-sale screen records a bill total; it does not yet create item-wise cart lines or deduct product stock.
Customer khata, supplier ledger, purchase orders, GST-compliant invoice numbering, tax filing reports,
barcode camera scanning, thermal printer integration, staff login/permissions, cloud backup,
multi-branch sync, PDF/Excel export and full Hindi/Bengali localization still need implementation.
No real bank account or payment gateway is connected.
Before real shop use, test calculations, add authentication/backup, configure tax rules with an accountant,
and create database migrations and automated tests.

## Suggested implementation phases
1. Product catalogue + cart billing + stock deduction + returns.
2. Customer/supplier ledgers + udhaar + purchase management.
3. GST configuration + invoices + cashbook + profit reports.
4. Staff roles + PIN security + printer/barcode.
5. Backup/restore + exports + localization + production QA.
