package com.arka.shopmanager.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ShopDao {
    @Query("SELECT * FROM products ORDER BY name")
    fun products(): Flow<List<Product>>

    @Query("SELECT * FROM products WHERE stockQty <= lowStockAt ORDER BY name")
    fun lowStockProducts(): Flow<List<Product>>

    @Insert
    suspend fun addProduct(product: Product)

    @Update
    suspend fun updateProduct(product: Product)

    @Query("SELECT * FROM sales ORDER BY createdAt DESC")
    fun sales(): Flow<List<Sale>>

    @Insert
    suspend fun addSale(sale: Sale)

    @Query("SELECT COALESCE(SUM(total),0) FROM sales WHERE status='COMPLETED'")
    fun totalSales(): Flow<Double>

    @Query("SELECT * FROM customers ORDER BY name")
    fun customers(): Flow<List<Customer>>

    @Insert
    suspend fun addCustomer(customer: Customer)

    @Query("SELECT * FROM suppliers ORDER BY name")
    fun suppliers(): Flow<List<Supplier>>

    @Insert
    suspend fun addSupplier(supplier: Supplier)

    @Query("SELECT * FROM expenses ORDER BY createdAt DESC")
    fun expenses(): Flow<List<Expense>>

    @Insert
    suspend fun addExpense(expense: Expense)
}
