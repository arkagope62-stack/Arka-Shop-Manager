package com.arka.shopmanager

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.arka.shopmanager.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = ShopDatabase.get(this)
        setContent { MaterialTheme { ShopApp(db.shopDao()) } }
    }
}

class ShopViewModel(private val dao: ShopDao) : ViewModel() {
    val products = dao.products().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val sales = dao.sales().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val customers = dao.customers().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val expenses = dao.expenses().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val totalSales = dao.totalSales().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)
    val lowStock = dao.lowStockProducts().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun addProduct(name: String, buy: String, sell: String, qty: String, unit: String) {
        if (name.isBlank()) return
        viewModelScope.launch {
            dao.addProduct(Product(name=name.trim(), purchasePrice=buy.toDoubleOrNull() ?: 0.0,
                sellingPrice=sell.toDoubleOrNull() ?: 0.0, stockQty=qty.toDoubleOrNull() ?: 0.0, unit=unit))
        }
    }
    fun addSale(amount: String, mode: String, customer: String) {
        val v = amount.toDoubleOrNull() ?: return
        if (v <= 0) return
        viewModelScope.launch { dao.addSale(Sale(customerName=customer.ifBlank { "Walk-in customer" },
            subtotal=v, total=v, paymentMode=mode, paid=v)) }
    }
    fun addCustomer(name: String, phone: String) {
        if (name.isBlank()) return
        viewModelScope.launch { dao.addCustomer(Customer(name=name.trim(), phone=phone.trim())) }
    }
    fun addExpense(title: String, amount: String) {
        val v=amount.toDoubleOrNull() ?: return
        if (title.isBlank() || v<=0) return
        viewModelScope.launch { dao.addExpense(Expense(title=title.trim(), amount=v)) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShopApp(dao: ShopDao) {
    val vm = remember { ShopViewModel(dao) }
    var page by remember { mutableStateOf("Home") }
    val pages = listOf("Home", "Products", "Billing", "Customers", "Expenses")
    Scaffold(
        topBar = { TopAppBar(title = {
            Column {
                Text("ARKA SHOP MANAGER", fontWeight=FontWeight.Bold)
                Text("Gandeswari Jharai maslar dokan", style=MaterialTheme.typography.labelSmall)
            }
        }) },
        bottomBar = {
            NavigationBar {
                val icons = listOf(Icons.Default.Home, Icons.Default.Inventory2, Icons.Default.PointOfSale, Icons.Default.People, Icons.Default.ReceiptLong)
                pages.forEachIndexed { i, p ->
                    NavigationBarItem(selected=page==p, onClick={page=p},
                        icon={ Icon(icons[i], contentDescription=p) }, label={Text(p)})
                }
            }
        }
    ) { padding ->
        when(page) {
            "Home" -> HomeScreen(vm, Modifier.padding(padding))
            "Products" -> ProductsScreen(vm, Modifier.padding(padding))
            "Billing" -> BillingScreen(vm, Modifier.padding(padding))
            "Customers" -> CustomersScreen(vm, Modifier.padding(padding))
            "Expenses" -> ExpensesScreen(vm, Modifier.padding(padding))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(vm: ShopViewModel, modifier: Modifier=Modifier) {
    val sales by vm.totalSales.collectAsState()
    val products by vm.products.collectAsState()
    val low by vm.lowStock.collectAsState()
    val expenses by vm.expenses.collectAsState()
    val expenseTotal = expenses.sumOf { it.amount }
    LazyColumn(modifier.fillMaxSize().padding(16.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
        item { Text("Namaste! 👋", style=MaterialTheme.typography.headlineMedium, fontWeight=FontWeight.Bold) }
        item { Text("Aaj ki dukaan ka overview", color=MaterialTheme.colorScheme.onSurfaceVariant) }
        item {
            Card(colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.primaryContainer)) {
                Column(Modifier.padding(18.dp)) {
                    Text("Recorded total sales")
                    Text(money(sales), style=MaterialTheme.typography.headlineLarge, fontWeight=FontWeight.Bold)
                    Text("All-time total · session-independent local database")
                }
            }
        }
        item { Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
            StatCard("Products", products.size.toString(), Modifier.weight(1f))
            StatCard("Low stock", low.size.toString(), Modifier.weight(1f))
        } }
        item { StatCard("Recorded expenses", money(expenseTotal), Modifier.fillMaxWidth()) }
        item { Text("Quick notes", style=MaterialTheme.typography.titleMedium, fontWeight=FontWeight.Bold) }
        item { Text("Add products before billing. This starter records sales totals but does not yet deduct individual item quantities.") }
        item { Text("Recent low-stock products", style=MaterialTheme.typography.titleMedium, fontWeight=FontWeight.Bold) }
        items(low) { Text("• ${it.name}: ${it.stockQty} ${it.unit}") }
    }
}

@Composable
fun StatCard(title: String, value: String, modifier: Modifier=Modifier) {
    Card(modifier) { Column(Modifier.padding(14.dp)) {
        Text(title, style=MaterialTheme.typography.labelMedium)
        Text(value, style=MaterialTheme.typography.titleLarge, fontWeight=FontWeight.Bold)
    } }
}

@Composable
fun ProductsScreen(vm: ShopViewModel, modifier: Modifier=Modifier) {
    val products by vm.products.collectAsState()
    var name by remember { mutableStateOf("") }
    var buy by remember { mutableStateOf("") }
    var sell by remember { mutableStateOf("") }
    var qty by remember { mutableStateOf("") }
    var unit by remember { mutableStateOf("piece") }
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Text("Product inventory", style=MaterialTheme.typography.headlineSmall, fontWeight=FontWeight.Bold)
        OutlinedTextField(name,{name=it},label={Text("Product name")},modifier=Modifier.fillMaxWidth())
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(buy,{buy=it},label={Text("Purchase ₹")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal),modifier=Modifier.weight(1f))
            OutlinedTextField(sell,{sell=it},label={Text("Selling ₹")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal),modifier=Modifier.weight(1f))
        }
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(qty,{qty=it},label={Text("Opening stock")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal),modifier=Modifier.weight(1f))
            OutlinedTextField(unit,{unit=it},label={Text("Unit")},modifier=Modifier.weight(1f))
        }
        Button(onClick={vm.addProduct(name,buy,sell,qty,unit);name="";buy="";sell="";qty=""},modifier=Modifier.fillMaxWidth()) { Text("Save product") }
        HorizontalDivider(Modifier.padding(vertical=10.dp))
        LazyColumn { items(products) { p ->
            ListItem(headlineContent={Text(p.name)}, supportingContent={Text("Buy ${money(p.purchasePrice)} · Sell ${money(p.sellingPrice)} · Stock ${p.stockQty} ${p.unit}")})
            HorizontalDivider()
        } }
    }
}

@Composable
fun BillingScreen(vm: ShopViewModel, modifier: Modifier=Modifier) {
    var amount by remember { mutableStateOf("") }
    var customer by remember { mutableStateOf("") }
    var mode by remember { mutableStateOf("Cash") }
    Column(modifier.fillMaxSize().padding(16.dp), verticalArrangement=Arrangement.spacedBy(10.dp)) {
        Text("Quick sale entry", style=MaterialTheme.typography.headlineSmall, fontWeight=FontWeight.Bold)
        Text("Starter billing: records a sale total. Item-wise cart, stock deduction, tax invoice and printer support are planned next.")
        OutlinedTextField(customer,{customer=it},label={Text("Customer name (optional)")},modifier=Modifier.fillMaxWidth())
        OutlinedTextField(amount,{amount=it},label={Text("Bill total ₹")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal),modifier=Modifier.fillMaxWidth())
        Text("Payment mode")
        Row(verticalAlignment=Alignment.CenterVertically) {
            listOf("Cash","UPI","Card","Credit").forEach { value ->
                Row(verticalAlignment=Alignment.CenterVertically) {
                    RadioButton(selected=mode==value,onClick={mode=value})
                    Text(value)
                }
            }
        }
        Button(onClick={vm.addSale(amount,mode,customer);amount="";customer=""},modifier=Modifier.fillMaxWidth()) { Text("Save sale") }
        val sales by vm.sales.collectAsState()
        Text("Sales history",style=MaterialTheme.typography.titleMedium)
        LazyColumn { items(sales) { s ->
            ListItem(headlineContent={Text(money(s.total))}, supportingContent={Text("${s.customerName} · ${s.paymentMode}")})
            HorizontalDivider()
        } }
    }
}

@Composable
fun CustomersScreen(vm: ShopViewModel, modifier: Modifier=Modifier) {
    val customers by vm.customers.collectAsState()
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Text("Customers",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)
        OutlinedTextField(name,{name=it},label={Text("Customer name")},modifier=Modifier.fillMaxWidth())
        OutlinedTextField(phone,{phone=it},label={Text("Mobile number")},modifier=Modifier.fillMaxWidth())
        Button(onClick={vm.addCustomer(name,phone);name="";phone=""},modifier=Modifier.fillMaxWidth()) { Text("Add customer") }
        LazyColumn { items(customers) { c ->
            ListItem(headlineContent={Text(c.name)}, supportingContent={Text(c.phone)})
            HorizontalDivider()
        } }
    }
}

@Composable
fun ExpensesScreen(vm: ShopViewModel, modifier: Modifier=Modifier) {
    val expenses by vm.expenses.collectAsState()
    var title by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Text("Shop expenses",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)
        OutlinedTextField(title,{title=it},label={Text("Expense name")},modifier=Modifier.fillMaxWidth())
        OutlinedTextField(amount,{amount=it},label={Text("Amount ₹")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal),modifier=Modifier.fillMaxWidth())
        Button(onClick={vm.addExpense(title,amount);title="";amount=""},modifier=Modifier.fillMaxWidth()) { Text("Save expense") }
        LazyColumn { items(expenses) { e ->
            ListItem(headlineContent={Text(e.title)}, trailingContent={Text(money(e.amount))})
            HorizontalDivider()
        } }
    }
}

fun money(value: Double): String =
    "₹" + NumberFormat.getNumberInstance(Locale("en","IN")).format(value)
